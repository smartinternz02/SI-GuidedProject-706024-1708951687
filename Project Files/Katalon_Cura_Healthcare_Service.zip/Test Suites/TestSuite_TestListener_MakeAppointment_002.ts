<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TestSuite_TestListener_MakeAppointment_002</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>suraj055vi@gmail.com;</mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>1b01a0a4-55e1-4eab-85f9-cbd4c88ebdb6</testSuiteGuid>
   <testCaseLink>
      <guid>e5a46e8b-44f1-4875-a6fc-03e9c29f9b53</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestListerner/TC_TestListener_MakeAppointment_002</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
